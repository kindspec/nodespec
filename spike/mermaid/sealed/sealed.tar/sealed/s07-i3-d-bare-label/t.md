# Alerting

```mermaid
graph TD
  pager[PagerDuty]
  monitor --> rules
  rules --> pager
  rules --> chat
  pager --> oncall
  chat --> channel
```

Warnings go to chat; outages page someone.
