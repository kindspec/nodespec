# Alerting

```mermaid
graph TD
  monitor --> rules
  rules --> pager
  rules --> chat
  pager --> oncall
  chat --> channel
```

Warnings go to chat; outages page someone.
