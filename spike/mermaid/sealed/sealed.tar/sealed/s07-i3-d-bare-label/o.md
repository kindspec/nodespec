# Alerting

```mermaid
graph TD
  monitor --> rules
  rules --> chat
  chat --> channel
```

Everything goes to chat for now.
