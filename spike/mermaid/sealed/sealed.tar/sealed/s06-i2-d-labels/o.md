# Site

```mermaid
flowchart LR
  home[Home page] --> catalog[Catalog]
  home --> search[Search results page]
  catalog --> product[Product page]
  product --> cart[Cart]
```

Pages are server-rendered.
