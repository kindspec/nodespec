# Site

```mermaid
flowchart LR
  home[Home page] --> catalog[Catalog]
  catalog --> product[Product page]
  product --> cart[Cart]
  catalog --> search[(Search index)]
```

Pages are server-rendered.
