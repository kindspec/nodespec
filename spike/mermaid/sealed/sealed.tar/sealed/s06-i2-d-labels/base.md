# Site

```mermaid
flowchart LR
  home[Home page] --> catalog[Catalog]
  catalog --> product[Product page]
  product --> cart[Cart]
```

Pages are server-rendered.
