# Hosting

```mermaid
flowchart LR
  subgraph Web tier
    nginx[Nginx]
    app[App server]
  end
  subgraph Data tier
    pg[(Postgres)]
    redis[(Redis)]
    cache[(Varnish)]
    s3[(S3)]
  end
  nginx --> cache --> app
  app --> pg
  app --> redis
```

Both tiers run in one region.
