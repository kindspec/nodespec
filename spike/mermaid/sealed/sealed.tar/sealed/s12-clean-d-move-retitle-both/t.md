# Hosting

```mermaid
flowchart LR
  subgraph Edge and app
    nginx[Nginx]
    cache[(Varnish)]
    app[App server]
  end
  subgraph Storage layer
    pg[(Postgres)]
    redis[(Redis)]
    s3[(S3)]
  end
  nginx --> cache --> app
  app --> pg
  app --> redis
```

Both tiers run in one region.
