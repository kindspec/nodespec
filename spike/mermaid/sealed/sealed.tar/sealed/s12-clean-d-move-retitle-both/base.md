# Hosting

```mermaid
flowchart LR
  subgraph Web tier
    nginx[Nginx]
    cache[(Varnish)]
    app[App server]
  end
  subgraph Data tier
    pg[(Postgres)]
    redis[(Redis)]
    s3[(S3)]
  end
  nginx --> cache --> app
  app --> pg
  app --> redis
```

Both tiers run in one region.
