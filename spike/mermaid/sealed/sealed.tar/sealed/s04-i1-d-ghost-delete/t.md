# Sign-in

```mermaid
flowchart TD
  browser[Browser] --> idp[Identity provider]
  idp --> ldap[(LDAP)]
  idp --> mfa[MFA service]
  ldap --> hr[(HR system)]
  mfa --> sms_gw[SMS gateway]
  vpn[VPN] --> ldap
```

Sessions last eight hours.
