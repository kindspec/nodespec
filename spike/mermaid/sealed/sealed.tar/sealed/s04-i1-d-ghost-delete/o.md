# Sign-in

```mermaid
flowchart TD
  browser[Browser] --> idp[Identity provider]
  idp --> mfa[MFA service]
  idp --> scim[SCIM directory]
  mfa --> sms_gw[SMS gateway]
```

Sessions last eight hours. The LDAP directory was replaced by SCIM.
