# Notifications

Users choose their channels in settings. SMS was withdrawn in March.

```mermaid
flowchart LR
  event --> router
  router --> email
  router --> push
  email --> ses
  push --> fcm
  ses --> bounces
```

Delivery receipts are stored for thirty days.
