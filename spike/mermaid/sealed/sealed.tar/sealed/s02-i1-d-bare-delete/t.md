# Notifications

Users choose their channels in settings.

```mermaid
flowchart LR
  event --> router
  router --> email
  router --> push
  router --> sms
  email --> ses
  push --> fcm
  sms --> carrier
  ses --> bounces
  push --> fcm_fallback
  sms --> twilio
```

Delivery receipts are stored for thirty days.
