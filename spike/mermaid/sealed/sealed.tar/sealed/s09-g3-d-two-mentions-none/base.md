# Runtime

```mermaid
flowchart TB
  subgraph control [Control plane]
    scheduler[Scheduler]
    agent[Node agent]
  end
  subgraph telemetry [Telemetry]
    logs[(Log store)]
    agent --> logs
  end
  scheduler --> agent
```

Agents restart themselves on failure.
