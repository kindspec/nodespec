# Runtime

```mermaid
flowchart TB
  subgraph control [Control plane]
    scheduler[Scheduler]
  end
  agent[Node agent]
  subgraph telemetry [Telemetry]
    logs[(Log store)]
    agent --> logs
  end
  scheduler --> agent
```

Agents restart themselves on failure. Agents run on every worker host, so
they sit outside the control plane.
