# Runtime

```mermaid
flowchart TB
  subgraph control [Control plane]
    scheduler[Scheduler]
    agent[Node agent]
  end
  subgraph telemetry [Telemetry]
    logs[(Log store)]
  end
  scheduler --> agent
  agent --> logs
```

Agents restart themselves on failure.
