# Sealed fixtures

Written by F (§10.1, §10.4). These fixtures are synthetic and released under
CC0-1.0. Layout, `expect.json` fields, object conventions and F's readings
are the same as in `v-fixtures/README.md`.

| fixture | stratum | records (tier) | exposed |
|---|---|---|---|
| `s01-i1-f-bare-rename` | F | I1 (A) | yes |
| `s02-i1-d-bare-delete` | D | I1 (A) | yes |
| `s03-i1-f-ghost-rename` | F | I1 (B, ghost seen by L1) | yes |
| `s04-i1-d-ghost-delete` | D | I1 (B, ghost seen by L1) | yes |
| `s05-i2-f-bare-click` | F | I2 (A) | yes |
| `s06-i2-d-labels` | D | I2 (B, L2) | yes |
| `s07-i3-d-bare-label` | D | I1 (A), I3 (A) | yes |
| `s08-g1-f-two-mentions` | F | G1 (A) | no |
| `s09-g3-d-two-mentions-none` | D | G3 (A) | no |
| `s10-g2-f-dedupe-both` | F | G2 (A) | no |
| `s11-clean-f-rename-and-relabel` | F | none | no |
| `s12-clean-d-move-retitle-both` | D | none | no |
